# CalavitaMod

**Terraria: Vita Overdrive** — an independent PS Vita project aiming toward a clean-room adaptation inspired by Calamity Mod 1.5.1.006.

## Current status

This is only a VitaSDK startup-test application and an initial GitHub Actions build workflow. It is **not yet a Terraria or Calamity gameplay port**. The workflow has not yet been validated on a physical Vita.

## Build

1. Open the **Actions** tab.
2. Select **Build Vita Overdrive VPK**.
3. Choose **Run workflow**, or push a commit to `main`.
4. Download the `VitaOverdrive-VPK` artifact after a successful run.

## Controls

- **START** — exit the startup test.

## Notes

- Provisional title ID: `VODR00001`
- Intended output: `VitaOverdrive.vpk`
- Original Terraria/Calamity source code and assets are not included.
