#include <psp2/ctrl.h>
#include <psp2/kernel/processmgr.h>
#include <vita2d.h>

int main() {
    sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);
    vita2d_init();
    vita2d_font *font = vita2d_load_default_font();

    bool running = true;
    while (running) {
        SceCtrlData pad{};
        sceCtrlPeekBufferPositive(0, &pad, 1);
        if (pad.buttons & SCE_CTRL_START) running = false;

        vita2d_start_drawing();
        vita2d_clear_screen();
        if (font) {
            vita2d_font_draw_text(font, 28, 55, RGBA8(245, 220, 120, 255), 1.0f,
                                  "TERRARIA: VITA OVERDRIVE");
            vita2d_font_draw_text(font, 28, 95, RGBA8(230, 230, 230, 255), 0.8f,
                                  "Vita startup test");
            vita2d_font_draw_text(font, 28, 130, RGBA8(180, 210, 180, 255), 0.8f,
                                  "Press START to exit");
        }
        vita2d_end_drawing();
        vita2d_swap_buffers();
    }

    if (font) vita2d_free_font(font);
    vita2d_fini();
    sceKernelExitProcess(0);
    return 0;
}
